<?php
  $active = 'about';
  include('header.php');
  include('navlogo.php');
  include('socials.php');
  include('nav.php');
?>

<div class="container-flex">

  <div class="row" id="grContactHeader">
    <div class="col-10 mx-auto">
      <h2>About Us!</h2>
    </div>
  </div>

  <hr class="mediumHR"/>

  <div class="row">
    <div class="col-md-9 mx-auto" id="grAboutVideo">
      <div class="aboutYoutubeEmbed">
        <iframe src="https://www.youtube.com/embed/V1OpMnGXa78?controls=0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <!-- Info box one -->
  <section id="grAboutInfo">
    <div class="animation-element slide-left infoBox">
      <div class="col-md-10 offset-md-1">
        <div class="row">
          <i class="fas fa-layer-group homeIcon col-md-2"></i>
          <p class="col-md-10 aboutInfoText alignLeft">
            Garden Rooms UK are specialists in planning, constructing and installing
            architecturally stunning <strong>garden rooms</strong>. Using only the highest-quality materials, our
            products are built to last, and constructed for year-round use through all weather
            conditions.
          </p>
        </div>
      </div>
    </div>
    <hr class="smallHR"/>
    <!-- Info box two -->
    <div class="animation-element slide-left infoBox">
      <div class="col-md-10 offset-md-1">
        <div class="row">
          <i class="fas fa-dolly-flatbed homeIcon col-md-2 order-md-12"></i>
          <p class="col-md-10 order-md-1 aboutInfoText alignRight">
            Striving to offer the best quality product on the market for the most cost-effective
            price. The versatility of our buildings is what makes us stand out. With our wide
            range of uses, our products are built to suit a huge market for a variety of purposes.
          </p>
        </div>
      </div>
    </div>
    <hr class="smallHR"/>
    <!-- Info box three -->
    <div class="animation-element slide-left infoBox">
      <div class="col-md-10 offset-md-1">
        <div class="row">
          <i class="fas fa-warehouse homeIcon col-md-2"></i>
          <p class="col-md-10 aboutInfoText alignLeft">
            We believe in making the process as simple as possible with our transparent pricing.
            Our prices are based on internal footprint, meaning you get the most out of your
            building space, and know the exact amount of space being paid for. View our range
            of building models, with a range of different design and styling options for more
            information.
          </p>
        </div>
      </div>
    </div>
  </section>

</div>

<hr class="mediumHR"/>

<?php
  include('footer.php');
?>
