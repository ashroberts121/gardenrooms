<hr id="grNavHR">

<nav class="navbar-expand-md navbar-light rounded" id="grNavContainer">

  <button class="navbar-toggler button-click animated-icon-box" type="button" data-toggle="collapse" data-target="#grNav"
    aria-controls="grNav" aria-expanded="false" aria-label="Toggle navigation">
    <div class="animated-icon">
      <span></span><span></span><span></span><span></span>
    </div>
  </button>

  <div class="collapse navbar-collapse justify-content-md-center" id="grNav">

    <ul class="navbar-nav">
      <li class="nav-item <?php if($active == 'home'){echo 'active';};?>">
        <a class="nav-link" href="index.php">HOME<span class="sr-only"><?php if($active == 'home'){echo '(current)';};?></span></a>
      </li>
      <!-- NEED SORTING AS CONTENT IS COMPLETED -->
      <li class="nav-item <?php if($active == 'about'){echo 'active';};?>">
        <a class="nav-link" href="about.php">ABOUT<span class="sr-only"><?php if($active == 'about'){echo '(current)';};?></span></a>
      </li>
      <li class="nav-item <?php if($active == 'range'){echo 'active';};?>">
        <a style="color:lightgrey" class="disabled nav-link" href="#">OUR RANGE<span class="sr-only"><?php if($active == 'range'){echo '(current)';};?></span></a>
      </li>
      <li class="nav-item <?php if($active == 'uses'){echo 'active';};?>">
        <a style="color:lightgrey" class="disabled nav-link" href="#">POPULAR USES<span class="sr-only"><?php if($active == 'uses'){echo '(current)';};?></span></a>
      </li>

      <li class="nav-item <?php if($active == 'contact'){echo 'active';};?>">
        <a class="nav-link" href="contact.php">CONTACT US<span class="sr-only"><?php if($active == 'contact'){echo '(current)';};?></span></a>
      </li>
      <li class="nav-item <?php if($active == 'faqs'){echo 'active';};?>">
        <a class="nav-link" href="faqs.php">FAQs<span class="sr-only"><?php if($active == 'faqs'){echo '(current)';};?></span></a>
      </li>
    </ul>

  </div>
</nav>

<hr id="grNavHR">
