<?php
  $active = 'contact';
  include('header.php');
  include('navlogo.php');
  include('socials.php');
  include('nav.php');
?>

<div class="container-flex">
  <div class="row" id="grContactHeader">
    <div class="col-10 mx-auto">
      <h2>Get in touch today!</h2>
    </div>
  </div>

  <?php include('socials.php'); ?>

  <hr class="mediumHR"/>

  <div class="row">
    <div class="col-10 col-md-6 mx-auto contactInfo">
      <div class="row">
        <div class="col-md-6">
          <i class="fas fa-phone social2"></i>
          <p id="contactDetails">01244 911389</p>
        </div>
        <div class="col-md-6">
          <i class="fas fa-envelope social2"></i>
          <p id="contactDetails">sales@gardenroomsuk.com</p>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <div class="col-md-10 mx-auto">
    <div class="row">

      <div class="col-md-6 order-md-12" id="contactAddress">
        <h4>Garden Rooms UK</h4>
        <p>
          The Coach House<br />
          Old Coach Road<br />
          Broxton<br />
          Chester<br />
          CH3 9JL <br />
          England, UK
        </p>
        <hr class="smallHR" />
        <h4>Hours</h4>
        <p>
          Monday to Saturday: 09:00-17:00<br />
          Sunday: CLOSED
        </p>
      </div>

      <hr class="mediumHR" id="contactHR"/>

      <div class="col-md-6 order-md-11 text-center formBox">
        <form action="admin/contactprocess.php" method="post">
          <h4>Feel free to enquire below</h4>
          <div class="form-group">
            <input class="form-control" name="name" id="name" type="text" placeholder="Your Name *" required="required" data-validation-required-message="Please enter your name.">
            <p class="help-block text-danger"></p>
          </div>
          <div class="form-group">
            <input class="form-control" name="email" id="email" type="email" placeholder="Your Email *" required="required" data-validation-required-message="Please enter your email address.">
            <p class="help-block text-danger"></p>
          </div>
          <div class="form-group">
            <input class="form-control" name="phone" id="phone" type="tel" placeholder="Your Phone *" required="required" data-validation-required-message="Please enter your phone number.">
            <p class="help-block text-danger"></p>
          </div>
          <div class="form-group">
            <input class="form-control" name="subject" id="subject" type="text" placeholder="Subject *" required="required" data-validation-required-message="Please enter a subject.">
            <p class="help-block text-danger"></p>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" id="message" placeholder="Your Message *" required="required" data-validation-required-message="Please enter a message."></textarea>
            <p class="help-block text-danger"></p>
          </div>
          <div class="col-lg-8 offset-lg-2 text-center">
            <button class="submitButton" type="submit" name="submit">Send Message</button>
          </div>
        </form>
      </div>

    </div>

    <hr class="mediumHR"/>

    <!--GOOGLE MAP INTEGRATION-->
    <div class="row">
      <div class="col-12">
        <div class="mapouter">
          <div class="gmap_canvas">
            <iframe width="100%" height="300px" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5379.900306146184!2d-2.778614256425232!3d53.08373587393525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTPCsDA1JzA3LjIiTiAywrA0NSc1OS42Ilc!5e0!3m2!1sen!2sus!4v1628625996134!5m2!1sen!2sus" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
        </div>
      </div>
    </div>

  </div>

</div>

<hr class="mediumHR"/>

<?php
  include('footer.php');
?>
