<?php
  $active = 'range';
  include('header.php');
  include('admin/config.php');
  include('navlogo.php');
  include('socials.php');
  include('nav.php');
?>

<div class="container" id="itempageItemBox">

  <h1>Page Heading</h1>

  <div class="row" id="backToRange">
    <div class="col">
      <a href="range.php"><p>< Back to Our Range</p></a>
    </div>
  </div>

  <?php
    $getItem = $_GET['id'];
    $sql = $conn->query("SELECT * FROM items WHERE id='$getItem'");

    while($row = $sql->fetch_object()){
      $items[] = $row;
    }

    foreach($items as $item){
  ?>

  <div class="row">

    <div class="col-md-6" id="itempageImageBox">
      <img id="expandedImg" src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img1;?>">
      <div class="row">
        <div class="col">
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img1;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
        <div class="col">
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img2;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
        <?php
        if(!empty($item->img3)){
          echo '<div class="col" style="display:block">';
        }else{
          echo '<div class="col" style="display:none">';
        };
        ?>
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img3;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
        <?php
        if(!empty($item->img4)){
          echo '<div class="col" style="display:block">';
        }else{
          echo '<div class="col" style="display:none">';
        };
        ?>
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img4;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
        <?php
        if(!empty($item->img5)){
          echo '<div class="col" style="display:block">';
        }else{
          echo '<div class="col" style="display:none">';
        };
        ?>
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img5;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
        <?php
        if(!empty($item->img6)){
          echo '<div class="col" style="display:block">';
        }else{
          echo '<div class="col" style="display:none">';
        };
        ?>
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img6;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
        <?php
        if(!empty($item->img7)){
          echo '<div class="col" style="display:block">';
        }else{
          echo '<div class="col" style="display:none">';
        };
        ?>
          <img src="media/img/<?php echo $item->img_folder;?>/<?php echo $item->img7;?>" alt="<?php echo $item->img_folder;?> garden room" onclick="expandThumbnail(this);">
        </div>
      </div>
    </div>

    <div class="col-md-6" id="itempageInfoBox">
      <h3><?php echo $item->name;?></h3>
      <p>
        <?php echo $item->info;?>
      </p>
      <hr class="mediumHR" />
      <div class="row">
        <div class="col-4">
          <div id="divText1" style="display:block;">£<?php echo $item->price_md_flat;?></div>
          <div id="divText2" style="display:none;">£<?php echo $item->price_xl_flat;?></div>
          <div id="divText3" style="display:none;">£<?php echo $item->price_md_built;?></div>
          <div id="divText4" style="display:none;">£<?php echo $item->price_xl_built;?></div>
        </div>
        <div class="col-8">
          <select type="text" id="dropBox" onchange="changeSelect()">
            <option value="1">Regular (Flatpack)</option>
            <option value="2">Plus Size (Flatpack)</option>
            <option value="3">Regular (Built)</option>
            <option value="4">Plus Size (Built)</option>
          </select>
        </div>
      </div>
      <hr class="mediumHR" />
      <div class="col-12">
        <p>
          To inquire about purchasing this product, or for further information,
          please <a href="contact.php" id="itempageContact">contact us</a>.
        </p>
      </div>
    </div>

  </div>

  <hr class="largeHR itempageHR"/>

  <div class="row">

    <div class="col-12 mx-auto tab">
      <div class="row">
        <div class="col-lg-6">
          <button class="tablinks col-6" onclick="openTab(event, 'further')" id="defaultOpen"><p>Further Details</p></button>
          <button class="tablinks col-6" onclick="openTab(event, 'specs')"><p>Specifications</p></button>
        </div>
        <div class="col-lg-6">
          <button class="tablinks col-6" onclick="openTab(event, 'flatpack')"><p>Flatpack Info</p></button>
          <button class="tablinks col-6" onclick="openTab(event, 'sizeguide')"><p>Size Guide</p></button>
        </div>
      </div>
    </div>

    <hr class="greyHR"/>

    <div id="further" class="col-md-10 mx-auto tabcontent">
      <h3>Further Details</h3>
      <p>
        <?php echo $item->further_info;?>
      </p>
    </div>
    <div id="specs" class="col-md-10 mx-auto tabcontent">
      <h3>Specifications</h3>
      <p>
        <?php echo $item->specs;?>
      </p>
    </div>
    <div id="flatpack" class="col-md-10 mx-auto tabcontent">
      <h3>Flatpack Information</h3>
      <p>
        <?php echo $item->flatpack_info;?>
      </p>
    </div>
    <div id="sizeguide" class="col-md-10 mx-auto tabcontent">
      <h3>Size Guide</h3>
      <p>
        <?php echo $item->size_guide;?>
      </p>
    </div>

  </div>

  <hr class="largeHR" />

  <!-- <h3 class="my-4">Related Projects</h3>
  <div class="row">
    <div class="col-md-3 col-sm-6 mb-4">
      <a href="#">
            <img class="img-fluid" src="http://placehold.it/500x300" alt="">
          </a>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
      <a href="#">
            <img class="img-fluid" src="http://placehold.it/500x300" alt="">
          </a>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
      <a href="#">
            <img class="img-fluid" src="http://placehold.it/500x300" alt="">
          </a>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
      <a href="#">
            <img class="img-fluid" src="http://placehold.it/500x300" alt="">
          </a>
    </div>
  </div> -->

  <?php }//Close foreach ?>

</div>

<?php
  include('footer.php');
?>
