<div class="container-flex wip">
  <div class="row">
    <p class="col-10">
      <i class="fas fa-info"></i>
      This website is currently still in development, so not all pages are available at this time.
      <i class="fas fa-wrench"></i>
    </p>
  </div>
</div>
<style>
  .wip {
    background-color: #065fd4;
    color: white;
    height: auto;
  }
  .wip p {
    text-align: center;
    margin: 1rem auto;
  }
  .wip i {
    margin: 0 1rem;
  }
</style>
