<div class="container-flex" id="grFooter">
  <div class="row">
    <div class="col-md-6" id="footerLeft">
      <img src="media/img/gardenroomsuk_caption_nobg_grey.png"/>
      <p>UK’s Leading Garden Room & Office Provider</p>
    </div>
    <hr class="footerHRMobile"/>
    <div class="col-md-6" id="footerRight">
      <h5>Contact us..</h5>
      <div class="row">
        <div class="col-lg-4">
          <a href="https://www.youtube.com/channel/UCuEaj8cbeHxuSJ0zErkhzWg"><i class="fab fa-youtube"></i></a>
          <a href="https://www.instagram.com/garden.rooms.uk/?hl=en"><i class="fab fa-instagram"></i></a>
          <a href="https://www.facebook.com/Garden-Rooms-UK-104721177932987/"><i class="fab fa-facebook"></i></a>
        </div>
        <div class="col-lg-8">
          <span>M:</span> 01244 911389<br/>
          <span>E:</span> sales@gardenroomsuk.com
        </div>
      </div>
      <p>The Coach House | Old Coach Road | Broxton | CH3 9JL | Chester</p>
    </div>
  </div>
  <hr class="footerHR"/>
  <div class="row">
    <div class="col-12" id="footerBottom">
      <p>&copy; Copyright 2020 - Garden Rooms UK</p>
      <p>
        <a href="media/files/gardenroomsuk_privacypolicy.pdf">Privacy Policy</a> |
        <a href="https://policies.google.com/terms?hl=en-US">Terms & Conditions</a>
      </p>
    </div>
  </div>
</div>


<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Slick carousel scripts -->
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Contact form JavaScript -->
<script src="js/jqBootstrapValidation.js"></script>
<script src="js/contact_me.js"></script>

<!-- Custom scripts for this template -->
<script src="scripts/main.js"></script>

</body>

</html>
