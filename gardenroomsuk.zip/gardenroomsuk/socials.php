<div class="container-flex social-box">
  <a href="https://www.youtube.com/channel/UCuEaj8cbeHxuSJ0zErkhzWg"><i class="fab fa-youtube social"></i></a>
  <a href="https://www.instagram.com/garden.rooms.uk/?hl=en"><i class="fab fa-instagram social"></i></a>
  <a href="https://www.facebook.com/Garden-Rooms-UK-104721177932987/"><i class="fab fa-facebook social"></i></a>
</div>
