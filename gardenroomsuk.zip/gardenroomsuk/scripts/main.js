//Toggle navbar hamburger button animation
$(document).ready(function () {
  $('.button-click').on('click', function () {
    $('.animated-icon').toggleClass('open');
  });
});

// Animate smooth scrolling
$("a[href^='#']").on('click', function(e) {
   // prevent default anchor click behavior
   e.preventDefault();
   // store hash
   var hash = this.hash;
   // animate
   $('html, body').animate({
       scrollTop: $(hash).offset().top
     }, 700, function(){
       // when done, add hash to url
       // (default click behaviour)
       window.location.hash = hash;
     });
});
//////////////////////////////////

//Slide-in on-scroll animation
/*Interactivity to determine when an animated element in in view. In view elements trigger our animation*/
$(document).ready(function() {
  //window and animation items
  var animation_elements = $.find('.animation-element');
  var web_window = $(window);
  //check to see if any animation containers are currently in view
  function check_if_in_view() {
    //get current window information
    var window_height = web_window.height();
    var window_top_position = web_window.scrollTop();
    var window_bottom_position = (window_top_position + window_height);
    //iterate through elements to see if its in view
    $.each(animation_elements, function() {
      //get the element sinformation
      var element = $(this);
      var element_height = $(element).outerHeight();
      var element_top_position = $(element).offset().top;
      var element_bottom_position = (element_top_position + element_height);
      //check to see if this current container is visible (its viewable if it exists between the viewable space of the viewport)
      if ((element_bottom_position >= window_top_position) && (element_top_position <= window_bottom_position)) {
        element.addClass('in-view');
      } else {
        element.removeClass('in-view');
      }
    });
  }
  //on or scroll, detect elements in view
  $(window).on('scroll resize', function() {
      check_if_in_view()
    })
    //trigger our scroll event on initial load
  $(window).trigger('scroll');
});
//////////////////////////////////////////////////////////////////

//Carousel JS
$('#homecarousel').on('slide.bs.carousel', function (e) {
  var $e = $(e.relatedTarget);
  var idx = $e.index();
  var itemsPerSlide = 5;
  var totalItems = $('.carousel-item').length;

  if (idx >= totalItems-(itemsPerSlide-1)) {
    var it = itemsPerSlide - (totalItems - idx);
    for (var i=0; i<it; i++) {
      // append slides to end
      if (e.direction=="left") {
          $('.carousel-item').eq(i).appendTo('.carousel-inner');
      }
      else {
          $('.carousel-item').eq(0).appendTo('.carousel-inner');
      }
    }
  }
});

//Itempage image thumbnail
function expandThumbnail(imgs) {
  var expandImg = document.getElementById("expandedImg");
  expandImg.src = imgs.src;
  expandImg.parentElement.style.display = "block";
}

//Itempage tabs
function openTab(evt, tabName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click(); //default open tab

//Dropdown price change
function changeSelect() {
    if (document.getElementById("dropBox").value == "1") {
        document.getElementById('divText1').style.display = 'block';
        document.getElementById('divText2').style.display = 'none';
        document.getElementById('divText3').style.display = 'none';
        document.getElementById('divText4').style.display = 'none';
    }
    else if (document.getElementById("dropBox").value == "2") {
      document.getElementById('divText1').style.display = 'none';
      document.getElementById('divText2').style.display = 'block';
      document.getElementById('divText3').style.display = 'none';
      document.getElementById('divText4').style.display = 'none';
    }
    else if (document.getElementById("dropBox").value == "3") {
      document.getElementById('divText1').style.display = 'none';
      document.getElementById('divText2').style.display = 'none';
      document.getElementById('divText3').style.display = 'block';
      document.getElementById('divText4').style.display = 'none';
    }
    else if (document.getElementById("dropBox").value == "4") {
      document.getElementById('divText1').style.display = 'none';
      document.getElementById('divText2').style.display = 'none';
      document.getElementById('divText3').style.display = 'none';
      document.getElementById('divText4').style.display = 'block';
    }
}
