<?php

if (isset($_POST['submit'])){

  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];
  $formcontent="From: $name \nPhone: $phone \nMessage: $message";
  $recipient = "sales@gardenroomsuk.com";
  $mailheader = "From: $email \r\n";

  mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
  echo "Thank You!"?> Return to site <a href="http://www.gardenroomsuk.com/">here</a><?php;
}

?>
