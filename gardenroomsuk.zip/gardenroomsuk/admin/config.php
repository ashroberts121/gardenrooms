<?php

  //Assign database details to variables
  define('DBHOST', 'db5000679035.hosting-data.io');
  define('DBUSER', 'dbu1022052');
  define('DBPASS', 'GardenRoomsUK123!');
  define('DBNAME', 'dbs627802');

  //Setup database connection
  $conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);

  //Check if connection was successful
  if(!$conn){
      die("Error connecting to SQL Database: 'gardenroomsuk'");
  }else{
    //  echo "Connected Successfully to Database <br/>";
  }

  //Run session
  //session_start();

  date_default_timezone_set('Europe/London'); //Set timezone to London Timezone

?>
