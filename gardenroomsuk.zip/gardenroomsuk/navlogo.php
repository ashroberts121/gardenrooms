<div class="container-flex navlogo-box">
  <img src="media/img/gardenroomsuk_caption_nobg_grey.png"/>
</div>
