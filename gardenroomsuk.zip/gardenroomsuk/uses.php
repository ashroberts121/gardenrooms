<?php
  $active = 'uses';
  include('header.php');
  include('navlogo.php');
  include('socials.php');
  include('nav.php');
?>

<div class="container-flex">
  <section class="row" id="grUsesHeader">
    <div class="col-10 mx-auto">
      <h2>Popular Uses for Our Garden Rooms</h2>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec,
        mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id.
      </p>
    </div>
  </section>

  <hr class="mediumHR"/>

  <!-- Info box one -->
  <div class="animation-element slide-left usesItemBox usesItemLeft">
    <div class="col-lg-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <div id="mancave" class="carousel slide col-12" data-ride="carousel">
            <!-- The slideshow -->
            <div class="carousel-inner usesCarousel-inner">
              <div class="carousel-item active">
                <img src="media/img/uses/mancave1.jpg" alt="garden room mancave">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/mancave2.jpg" alt="garden room mancave">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/mancave3.jpg" alt="garden room mancave">
              </div>
            </div>
            <!-- Left and right controls -->
            <a class="carousel-control-prev" data-target="#mancave" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" data-target="#mancave" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>
          </div>
        </div>
        <div class="col-md-7 usesItemInfo">
          <h5>MAN CAVE</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <!-- Info box two -->
  <div class="animation-element slide-left usesItemBox usesItemRight">
    <div class="col-lg-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5 order-md-12">
          <div id="office" class="carousel slide col-12" data-ride="carousel">
            <!-- The slideshow -->
            <div class="carousel-inner usesCarousel-inner">
              <div class="carousel-item active">
                <img src="media/img/uses/office1.jpg" alt="garden room office">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/office2.jpg" alt="garden room office">
              </div>
            </div>
            <!-- Left and right controls -->
            <a class="carousel-control-prev" data-target="#office" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" data-target="#office" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>
          </div>
        </div>
        <div class="col-md-7 order-md-1 usesItemInfo usesItemLeft">
          <h5>HOME OFFICE</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <!-- Info box three -->
  <div class="animation-element slide-left usesItemBox usesItemLeft">
    <div class="col-lg-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <div id="gym" class="carousel slide col-12" data-ride="carousel">
            <!-- The slideshow -->
            <div class="carousel-inner usesCarousel-inner">
              <div class="carousel-item active">
                <img src="media/img/uses/gym1.jpg" alt="garden room gym">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/gym2.jpg" alt="garden room gym">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/gym3.jpg" alt="garden room gym">
              </div>
            </div>
            <!-- Left and right controls -->
            <a class="carousel-control-prev" data-target="#gym" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" data-target="#gym" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>
          </div>
        </div>
        <div class="col-md-7 usesItemInfo">
          <h5>HOME GYM</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <!-- Info box four -->
  <div class="animation-element slide-left usesItemBox usesItemRight">
    <div class="col-lg-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5 order-md-12">
          <div id="spa" class="carousel slide col-12" data-ride="carousel">
            <!-- The slideshow -->
            <div class="carousel-inner usesCarousel-inner">
              <div class="carousel-item active">
                <img src="media/img/uses/spa1.jpg" alt="garden room spa">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/spa2.jpg" alt="garden room spa">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/spa3.jpg" alt="garden room spa">
              </div>
            </div>
            <!-- Left and right controls -->
            <a class="carousel-control-prev" data-target="#spa" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" data-target="#spa" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>
          </div>
        </div>
        <div class="col-md-7 order-md-1 usesItemInfo usesItemLeft">
          <h5>SPA / RELAXATION ROOM</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <!-- Info box five -->
  <div class="animation-element slide-left usesItemBox usesItemLeft">
    <div class="col-lg-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <div id="bar" class="carousel slide col-12" data-ride="carousel">
            <!-- The slideshow -->
            <div class="carousel-inner usesCarousel-inner">
              <div class="carousel-item active">
                <img src="media/img/uses/bar1.jpg" alt="garden room bar">
              </div>
              <div class="carousel-item">
                <img src="media/img/uses/bar2.jpg" alt="garden room bar">
              </div>
            </div>
            <!-- Left and right controls -->
            <a class="carousel-control-prev" data-target="#bar" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" data-target="#bar" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>
          </div>
        </div>
        <div class="col-md-7 usesItemInfo">
          <h5>GARDEN BAR / PUB</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

  <div class="row">
    <div class="col-md-8 col-sm-10 mx-auto usesOther">
      <h2>Other uses...</h2>
      <div class="row">
        <div class="col-6">
          <div class="col-lg-7 col-md-9 col-8 mx-auto">
            <p>• Games Room</p>
            <p>• Cinema Room</p>
            <p>• AirBNB</p>
            <p>• Guest Room</p>
            <p>• Nail Studio</p>
            <p>• Home Salon</p>
            <p>• Garden Sauna</p>
          </div>
        </div>
        <div class="col-6">
          <div class="col-lg-7 col-md-9 col-9 mx-auto">
            <p>• Music Room</p>
            <p>• Art Studio</p>
            <p>• Yoga Ashram</p>
            <p>• Care Unit</p>
            <p>• Photography Studio</p>
            <p>• Hobby Room</p>
            <p>• Memorabilia Room</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

</div>

<?php
  include('footer.php');
?>
