<?php
  $active = 'home';
  include('header.php');
  include('nav.php');
  include('socials.php');
?>
<!--fb social feed script-->
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v10.0" nonce="FGsjfnAM"></script>

<link href="css/homecarousel.css" rel="stylesheet">

<header id="grHeader">
  <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop>
    <source src="media/video/grass_bg.mp4" type="video/mp4">
  </video>
  <div class="container-flex" id="grLogoContainer">
    <img src="media/img/gardenroomsuk_caption_nobg_white.png" alt="garden rooms uk">
    <br /><br /><br />
    <section id="scrolldown-arrows" class="demo">
      <a href="#home">
        <span></span>
        <span></span>
        <span></span>
      </a>
    </section>
  </div>
</header>

<div class="container-flex" id="home">
  <section id="grHomeInfo">

    <hr class="smallHR"/>
    <h1 class="mx-1">Welcome to Garden Rooms UK!</h1>
    <hr class="smallHR"/>

    <!--Embedded youtube video-->
    <div class="col-12 col-lg-10 offset-lg-1 p-0">
      <div class="homeYoutubeEmbed">
        <iframe src="https://www.youtube.com/embed/V1OpMnGXa78?controls=0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>

  </section>
</div>

<hr class="largeHR"/>

<!--Social media feeds-->
<div class="container-flex">
  <div class="row">
    <div class="homeSocialFeedFB col p-0">
      <div class="fb-page" data-href="https://www.facebook.com/Garden-Rooms-UK-104721177932987/" data-tabs="timeline" data-width="500" data-height="500" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true"><blockquote cite="https://www.facebook.com/Garden-Rooms-UK-104721177932987/" class="fb-xfbml-parse-ignore">
        <a href="https://www.facebook.com/Garden-Rooms-UK-104721177932987/">Garden Rooms UK</a></blockquote>
      </div>
    </div>
  </div>
</div>

<hr class="largeHR"/>

<!-- Top content -->
<div class="top-content">
    <div class="container-fluid p-0">
        <div id="homecarousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner homeCarousel-inner row w-100 mx-auto" role="listbox">
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3 active">
                    <a href="#"><img src="media/img/classic/classic1.jpg" class="img-fluid mx-auto d-block" alt="img1"></a>
                    <div class="carousel-item-overlay">
                      <h6>CLASSIC</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=1"><button>More info..</button></a>
                    </div>
                </div>
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                    <img src="media/img/leisure/leisure2.jpg" class="img-fluid mx-auto d-block" alt="img2">
                    <div class="carousel-item-overlay">
                      <h6>TRADITIONAL</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=2"><button>More info..</button></a>
                    </div>
                </div>
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                    <img src="media/img/modern/modern1.jpg" class="img-fluid mx-auto d-block" alt="img3">
                    <div class="carousel-item-overlay">
                      <h6>MODERN</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=3"><button>More info..</button></a>
                    </div>
                </div>
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                    <img src="media/img/classic/classic1.jpg" class="img-fluid mx-auto d-block" alt="img4">
                    <div class="carousel-item-overlay">
                      <h6>DELUXE</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=4"><button>More info..</button></a>
                    </div>
                </div>
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                    <img src="media/img/modern/modern1.jpg" class="img-fluid mx-auto d-block" alt="img5">
                    <div class="carousel-item-overlay">
                      <h6>CONTEMPORARY</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=5"><button>More info..</button></a>
                    </div>
                </div>
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                    <img src="media/img/leisure/leisure1.jpg" class="img-fluid mx-auto d-block" alt="img6">
                    <div class="carousel-item-overlay">
                      <h6>LEISURE</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=6"><button>More info..</button></a>
                    </div>
                </div>
                <!--
                <div class="carousel-item homeCarousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                    <img src="media/img/care/care1.jpg" class="img-fluid mx-auto d-block" alt="img6">
                    <div class="carousel-item-overlay">
                      <h6>CARE</h6>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit,
                        vulputate eu pharetra nec, mattis ac neque.
                      </p>
                      <a href="itempage.php?id=7"><button>More info..</button></a>
                    </div>
                </div>
              -->
            </div>
            <a class="carousel-control-prev ctrl-prev" data-target="#homecarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next ctrl-next" data-target="#homecarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</div>
<!--
<h4 class="homeCarouselCaption">View our full collection <a href="range.php"><span>here</span></a>!</h4>
-->

<hr class="largeHR"/>

<?php
  include('footer.php');
?>
