<?php
  $active = 'range';
  include('header.php');
  include('navlogo.php');
  include('socials.php');
  include('nav.php');
?>

<div class="container-flex">
  <section class="row" id="grRangeHeader">
    <div class="col-10 mx-auto">
      <h2>Our Range of Garden Rooms</h2>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec,
        mattis ac neque. Duis vulputate commodo lectus, ac blandit elit tincidunt id.
      </p>
    </div>
  </section>

  <hr class="mediumHR"/>

  <!-- Info box one -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <img src="media/img/classic/classic1.jpg"/>
        </div>
        <div class="col-md-7 rangeItemInfo">
          <h5>CLASSIC</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=1"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>
  <!-- Info box two -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5 order-md-12">
          <img src="media/img/traditional/traditional1.jpg"/>
        </div>
        <div class="col-md-7 order-md-1 rangeItemInfo" id="rangeItemRight">
          <h5>TRADITIONAL</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=2"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>
  <!-- Info box three -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <img src="media/img/modern/modern1.jpg"/>
        </div>
        <div class="col-md-7 rangeItemInfo">
          <h5>MODERN</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=3"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>
  <!-- Info box four -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5 order-md-12">
          <img src="media/img/deluxe/deluxe1.jpg"/>
        </div>
        <div class="col-md-7 order-md-1 rangeItemInfo"  id="rangeItemRight">
          <h5>DELUXE</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=4"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>
  <!-- Info box five -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <img src="media/img/contemporary/contemporary1.jpg"/>
        </div>
        <div class="col-md-7 rangeItemInfo">
          <h5>CONTEMPORARY</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=5"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>
  <!-- Info box six -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5 order-md-12">
          <img src="media/img/leisure/leisure1.jpg"/>
        </div>
        <div class="col-md-7 order-md-1 rangeItemInfo" id="rangeItemRight">
          <h5>LEISURE ROOMS</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=6"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>
  <!-- Info box seven -->
  <div class="animation-element slide-left rangeItemBox">
    <div class="col-md-9 col-sm-10 mx-auto">
      <div class="row">
        <div class="col-md-5">
          <img src="media/img/care/care1.jpg"/>
        </div>
        <div class="col-md-7 rangeItemInfo">
          <h5>CARE UNITS</h5>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.
            Duis vulputate commodo lectus, ac blandit elit tincidunt id.
            Sed rhoncus, tortor sed eleifend tristique, tortor mauris molestie elit,
            et lacinia ipsum quam nec dui.
          </p>
          <a href="itempage.php?id=7"><button>More info..</button></a>
        </div>
      </div>
    </div>
  </div>
  <hr class="mediumHR"/>

</div>

<?php
  include('footer.php');
?>
