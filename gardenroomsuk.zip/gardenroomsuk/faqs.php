<?php
  $active = 'faqs';
  include('header.php');
  include('admin/config.php');
  include('navlogo.php');
  include('socials.php');
  include('nav.php');
?>

<div class="container-flex">

  <section class="row" id="grFAQHeader">
    <div class="col-10 mx-auto">
      <h2>Frequently Asked Questions</h2>
    </div>
  </section>

  <hr class="mediumHR"/>

  <div class="row">
    <div class="col-md-8 mx-auto">
      <div class="tab-content" id="faq-tab-content">
        <div class="tab-pane show active" id="tab1" role="tabpanel" aria-labelledby="tab1">
          <div class="accordion" id="accordion-tab-1">

            <?php
            //Display all rows from blogs in descending order
            $sql = "SELECT * FROM faqs ORDER BY id ASC";
            $result = $conn->query($sql);
                //Run while there is data available
                while($row = $result->fetch_object()){
                ?>

            <div class="card">
              <div class="card-header" id="accordion-tab-1-heading-<?php echo $row->id?>">
                <h5>
                  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#accordion-tab-1-content-<?php echo $row->id?>" aria-expanded="false" aria-controls="accordion-tab-1-content-<?php echo $row->id?>"><?php echo $row->question?></button>
                </h5>
              </div>
              <div class="<?php if(($row->id) == 1){echo 'collapse show';}else{echo 'collapse';}?>" id="accordion-tab-1-content-<?php echo $row->id?>" aria-labelledby="accordion-tab-1-heading-<?php echo $row->id?>" data-parent="#accordion-tab-1">
                <div class="card-body">
                  <p><?php echo $row->answer?></p>
                </div>
              </div>
            </div>

            <?php } ?>

          </div>
        </div>
      </div>
    </div>
  </div>

  <hr class="mediumHR"/>

</div><!--container-flex-->

<?php
  include('footer.php');
?>
